import java.util.Scanner;

public class Sales extends Company {
    int SellID;
    String Sellname;
    String Selltype;
    String Selldescription;
    public Sales(int SellD,String Sellnm,String Selltp,String Selldesc){

    }
    public void getSellID(){
        Scanner MC=new Scanner(System.in);
        System.out.println("enter sellId");
        int sellId=MC.nextInt();
    }
    public void getSellname(){
        Scanner hb=new Scanner(System.in);
        System.out.println("enter the name of sell");
        String Sellname=hb.nextLine();
    }
    

public void getSelltype(){
    Scanner guc=new Scanner(System.in);
    System.out.println("enter the selltype");
    String Selltype=guc.nextLine();
}
public void getSelldescription(){
    Scanner mercury=new Scanner(System.in);
    System.out.println("enter Selldescription");
    String Selldescription=mercury.nextLine();
}
public void setSellID(){
    SellID=SellID;
}
public void setSellname(){
    Sellname=Sellname;
}
public void setSelltype(){
    Selltype=Selltype;
}
public void setSelldescription(){
Selldescription=Selldescription;
}
}

