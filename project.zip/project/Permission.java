import java.util.Scanner;

public class Permission extends Company {
    private int PermissionId;
    private int Permissionrole;
    private String permissiontitle;
    private String permissionmodule;
    private String permissiondescription;
    public Permission(int PermissionI,int Permissionrl,String permissiontil,String permissiondule,String permissiondesc){
      this.PermissionId=PermissionI;
      this.Permissionrole=Permissionrl;
      this.permissiontitle=permissiontil;
      this.permissionmodule=permissiondule;
      this.permissiondescription=permissiondesc;  
    }
    public void setpermissionI(){
        PermissionId=PermissionId;
    }
    public void setpermissionrl(){
Permissionrole=Permissionrole;
    }
    public void setpermissiontil(){
        permissiontitle=permissiontitle;

    }
    public void setpermissiondule(){
        permissionmodule=permissionmodule;
    }
    public void setpermissiondesc(){
        permissiondescription =permissiondescription;
    }
    public void getpermissionI(){
        Scanner NI=new Scanner(System.in);
        System.out.println("enter permission Id");
        int PermissionI=NI.nextInt();
    }
    public void getpermissionrl(){
        Scanner gl= new Scanner(System.in);
        System.out.println("enter permision role");
        int Permissionrole=gl.nextInt();
    }
    public void getpermissiontil(){
        Scanner tl= new Scanner(System.in);
        System.out.println("enter permision title");
        String Permissiontitle=tl.nextLine();
    }
    public void getpermissiondule(){
        Scanner dl= new Scanner(System.in);
        System.out.println("enter permision module");
        String Permissionmodule=dl.nextLine();
    }
    public void getpermissiondesc(){
        Scanner dec= new Scanner(System.in);
        System.out.println("enter permision description");
        String permissiondesc=dec.nextLine();
    }
}
