import java.util.Scanner;

public class Role {
    private int RoleId;
    private String Roletitle;
    private  String Roledescription;
    public Role(int RoleId,String Roletitle, String Roledescription){

    }
    public void setRoleId(){
        RoleId=RoleId;
    }
    public void setRoletitle(){
        Roletitle=Roletitle;
    }
    public void setRoledescription(){
        Roledescription=Roledescription;
    }
    public void getRoleId(){
        Scanner rl=new Scanner(System.in);
        System.out.println("enter roleid");
        int roleid= rl.nextInt();
    }
    public void getRoletitle(){
        Scanner tl=new Scanner(System.in);
        System.out.println("enter role title");
        String Roletitle=tl.nextLine();
    }
    public void getRoledescription(){
        Scanner rd=new Scanner(System.in);
        System.out.println("enter role description");
        String Roledescription=rd.nextLine();
    }
    
}
