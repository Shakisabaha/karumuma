import java.sql.Date;
import java.util.Scanner;

public class User extends Company {
   private int UserId;
   private int Userrole;
   private String Username;
   private String Useremail;
   private String Useraddress;
   private Date Userdob;
   public User(int UserIdIn,int UserroleIn,String UsernameIn,String UseremailIn,String UseraddressIn,Date UserdobIn){
this.UserId=UserIdIn;
this.Userrole=UserroleIn;
this.Username=UsernameIn;
this.Useremail=UseremailIn;
this.Useraddress=UseraddressIn;
this.Userdob=UserdobIn;

   }
   public void getuserId(){
    Scanner hex=new Scanner(System.in);
    System.out.println("enter userid");
    int userid=hex.nextInt();

   }
   public void getuserrole(){
    Scanner hf=new Scanner(System.in);
    System.out.println("enter userrole");
    int userrole=hf.nextInt();

   }
   public void getusername(){
    Scanner hec=new Scanner(System.in);
    System.out.println("enter username");
    String username=hec.nextLine();

   }
   public void getuseremail(){
    Scanner em=new Scanner(System.in);
    System.out.println("enter useremail");
    String useremail=em.nextLine();

   }
   public void getuseraddress(){
    Scanner dd=new Scanner(System.in);
    System.out.println("enter useraddress");
    String useraddress=dd.nextLine();


   }
   public void getuserdob(){
    Scanner bth=new Scanner(System.in);
    System.out.println("enter userdate of birth");
    int dob = bth.nextInt();

   }
   public void setuserIdIn(){
    UserId=UserId;
   }
   public void setuserroleIn(){
    Userrole=Userrole;
   }
   public void setusernameIn(){
    Username=Username;
   }
   public void setuseremailIn(){
    Useremail=Useremail;
   }
   public void setuseraddressIn(){
    Useraddress=Useraddress;
   }
   public void setuserdobIn(){
    Userdob=Userdob;
   }
    
    
}
