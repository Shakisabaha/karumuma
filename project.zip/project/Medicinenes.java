import java.util.Scanner;

class Medicinenes extends Company {
    int Medicines_id;
    String Medicines_name;
    String Medicine_company;
    String Medicine_cost;
    String Medicines_dose;
    public Medicinenes(int Medicines_idIn,String Medicines_nameIn,String medicine_companyIn, String Medicine_costIn, String Medicines_doseIn){
        this.Medicines_id=Medicines_idIn;
        this.Medicines_name=Medicines_nameIn;
        this.Medicine_company=medicine_companyIn;
        this.Medicine_cost=Medicine_costIn;
        this.Medicines_dose=Medicines_doseIn;
    }
    public void getmedicines_Id(){
        Scanner sof = new Scanner(System.in);
        System.out.println("enter medicines_id");
        int medicines_id= sof.nextInt();

    }
    public void getmedicines_nane(){
        Scanner RT = new Scanner(System.in);
        System.out.println("enter medicines_name");
        String medicines_name= RT.nextLine();
    }
    public void getmedicines_company(){
        Scanner wx = new Scanner(System.in);
        System.out.println("enter medicines_company");
        String medicines_company= wx.nextLine();
    }
    public void getmedicines_cost(){
        Scanner TP = new Scanner(System.in);
        System.out.println("enter medicines_cost");
        String medicines_cost= TP.nextLine();
    }
    public void getmedicines_dose(){
        Scanner dx = new Scanner(System.in);
        System.out.println("enter medicines_dose");
        String medicines_dose= dx.nextLine();
    }
    public void setmedicines_id(){
        Medicines_id=Medicines_id;
    }
    public void setmedicines_name(){
        Medicines_name=Medicines_name;
    }
    public void setmedicines_company(){
        Medicine_company=Medicine_company;
    }
    public void setmedicines_cost(){
        Medicine_cost=Medicine_cost;
    }
    public void setmedicines_dose(){
        Medicines_dose=Medicines_dose;
    }




     
    
}
