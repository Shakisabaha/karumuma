import java.util.Scanner;

public class Stock extends Company {
    private int StockId;
    private String StockItem;
    private String Stocktype;
    private String Stocknumber;
     private String Stockdescription;
     public Stock(int StockI,String StockIem,String Stocktye, String Stocknumbr,String Stockdesc){
        this.StockId=StockI;
        this.StockItem=StockIem;
        this.Stocktype=Stocktye;
        this.Stocknumber=Stocknumbr;
        this.Stockdescription=Stockdesc;
     }
     public void getstockId(){
        Scanner ip=new Scanner(System.in);
        System.out.println("enter stockId");
        int stockId=ip.nextInt();
     }
     public void getstockitem(){
        Scanner bf = new Scanner(System.in);
        System.out.println("enter stockitem");
        String stockitem=bf.nextLine();
     }
     public void getstocktype(){
        Scanner wise = new Scanner(System.in);
        System.out.println("enter stocktype");
        String stockitem=wise.nextLine();
     }
     public void getstocknumber(){
        Scanner gk = new Scanner(System.in);
        System.out.println("enter stocknumber");
        String stockitem=gk.nextLine();
     }
     public void getstockdesc(){
        Scanner input = new Scanner(System.in);
        System.out.println("enter stockdescription");
        String stockitem=input.nextLine();
     }
     public void setstockI(){
        StockId=StockId;
     }
     public void setstockitem(){
        StockItem=StockItem;
     }
     public void setstocktype(){
        Stocktype=Stocktype;
     }
     public void setstocknumber(){
        Stocknumber=Stocknumber;
     }
     public void setstockdesc(){
        Stockdescription=Stockdescription;
     }

}
