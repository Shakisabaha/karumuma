import java.util.Scanner;

public class Inventory extends Company {
    int Inventory_id;
    String Inventory_number;
    String Inventory_type;
    String Inventory_item;
    String Inventory_description;
    public Inventory(int Inventory_idin,String Inventory_numberin,String Inventory_typein,String Inventory_itemin,String Inventory_descriptionin ){
        this.Inventory_id=Inventory_idin;
        this.Inventory_number=Inventory_numberin;
        this.Inventory_type=Inventory_typein;
        this.Inventory_item=Inventory_itemin;
        this.Inventory_description=Inventory_descriptionin;
    }
    public void getInventory_id(){
        Scanner bp=new Scanner(System.in);
        System.out.println("enter Inventory_id");
        int Inventory_id=bp.nextInt();
    }
    public void getInventory_number(){
        Scanner ceo=new Scanner(System.in);
        System.out.println("enter Inventory_number");
        String Inventory_number=ceo.nextLine();
    }
    public void getInventory_type(){
        Scanner ce=new Scanner(System.in);
        System.out.println("enter Inventory_type");
        String Inventory_number=ce.nextLine();
    }
    public void getInventory_item(){
        Scanner xh=new Scanner(System.in);
        System.out.println("enter Inventory_item");
        String Inventory_item=xh.nextLine();
    }
    public void getInventory_description(){
        Scanner px=new Scanner(System.in);
        System.out.println("enter Inventory_description");
        String Inventory_number=px.nextLine();
    }
    public void setInventoryid(){
        Inventory_id=Inventory_id;
    }
    public void setInventorynumber(){
        Inventory_number=Inventory_number;
    }
    public void setInventorytype(){
        Inventory_type=Inventory_type;
    }
    public void setInventoryitem(){
        Inventory_item=Inventory_item;
    }
    public void setInventorydescription(){
        Inventory_description=Inventory_description;
    }
    

    }

