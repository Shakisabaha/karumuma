import java.util.Scanner;

class Company{
    int companyid;
    String company_name;
    String company_type;
    String company_discription;
    public void getcompany_id(){
        Scanner input = new Scanner(System.in);
        System.out.println("enter comany id");
        int company_id=input.nextInt();

    }
     public void getcompany_name() {
        Scanner get = new Scanner(System.in);
        System.out.println("enter company_name ");
        String company_name=get.nextLine();
    
} 
public void getcompany_type() {
        Scanner zf = new Scanner(System.in);
        System.out.println("enter company_type");
        String company_type=zf.nextLine();
} 
public void getcompany_description(){
    Scanner bye = new Scanner(System.in);
        System.out.println("enter company_description");
        String company_description=bye.nextLine();

}
public void setcompany_name(){
    company_name=company_name;

}
public void setcompany_id(){
    companyid=companyid;
}
public void setcompany_type(){
    company_type=company_type;
}
public void setcompany_description(){
    company_discription=company_discription;

}
   
}


